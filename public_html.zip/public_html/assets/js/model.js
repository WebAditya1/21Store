import * as views from "./view.js";
import * as Main from "./main.js";

const Model = {
    // make changes here...
    data: {
        products: [
            { 	
                id: 1,
                name: "Already Broken Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/alreadybroken_blue.jpg"
                    },                  
                    {
                        id: 2,
                        path: "assets/images/alreadybroken_red.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/alreadybroken_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/alreadybroken_sblue.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/alreadybroken_wine.jpg"
                    },
                    {
                        id: 6,
                        path: "assets/images/alreadybroken_yellow.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Red",
                        value: "#A61E1A",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 5,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 6,
                        name: "Yellow",
                        value: "#B48124",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 1,
                description: "This is a version of designer T-Shirt giving us some vibes of PEAKY BLINDERS",																desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 2,
                name: "Brown Munde Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/brownMunde_nblue.jpg"
                    },                 
                    {
                        id: 2,
                        path: "assets/images/brownMunde_Black.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/brownMunde_wine.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/brownMunde_white.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#171623",
                    },                 
                    {
                        id: 2,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 3,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 4,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "This is a version of designer T-Shirt giving us some vibes of BROWN MUNDE",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 3,
                name: "IGNORE Text Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/ignore_nblue.jpg"
                    },                  
                    {
                        id: 2,
                        path: "assets/images/ignore_red.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/ignore_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/ignore_sblue.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/ignore_wine.jpg"
                    },
                    {
                        id: 6,
                        path: "assets/images/ignore_yellow.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Red",
                        value: "#A61E1A",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 5,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 6,
                        name: "Yellow",
                        value: "#B48124",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "A Designer T-Shirt giving us some savage vibes of Ignoring a Text",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 4,
                name: "Keep Calm Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/pyaar_Blue.jpg"
                    },                  
                    {
                        id: 2,
                        path: "assets/images/pyaar_Wine.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/pyaar_Black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/pyaar_White.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  	
                    {
                        id: 2,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "The print on this T-shirt describes it all :) ",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 5,
                name: "Lost A Teddy Bear Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/teddy_nblue.jpg"
                    },                  
                    {
                        id: 2,
                        path: "assets/images/teddy_red.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/teddy_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/teddy_sblue.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/teddy_wine.jpg"
                    },
                    {
                        id: 6,
                        path: "assets/images/teddy_yellow.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Red",
                        value: "#A61E1A",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 5,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 6,
                        name: "Yellow",
                        value: "#B48124",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "Know How to flirt ? Well , A T-Shirt can teach you!",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 6,
                name: "Life Well Explained Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/me_red.jpg"
                    },
                    {
                        id: 2,
                        path: "assets/images/me_sblue.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/me_wine.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/me_yellow.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/me_white.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Red",
                        value: "#A61E1A",
                    },
                    {
                        id: 2,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 3,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 4,
                        name: "Yellow",
                        value: "#B48124",
                    },
                    {
                        id: 5,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "This T-shirt explains the life of an Engineering student well in the form of a Venn Diagram!",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 7,
                name: "Parental Adivsory Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/Parental_blue.jpg"
                    },                  
                    {
                        id: 2,
                        path: "assets/images/Parental_wine.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/Parental_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/Parental_white.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "White",
                        value: "#F3F2F9",
                    },

                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "PARENTAL Advisory Explicit Content",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 8,
                name: "POST MALONE Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/post_blue.jpg"
                    },                 
                    {
                        id: 2,
                        path: "assets/images/post_red.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/post_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/post_sblue.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/post_wine.jpg"
                    },
                    {
                        id: 6,
                        path: "assets/images/post_yellow.jpg"
                    },
                    {
                        id: 7,
                        path: "assets/images/post_white.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Red",
                        value: "#A61E1A",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 5,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 6,
                        name: "Yellow",
                        value: "#B48124",
                    },
                    {
                        id: 7,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "We all know POST MALONE Right ? For those who don't GOOGLE might help",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 9,
                name: "Science Bitch Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/ScienceBitch_blue.jpg"
                    },                  
                    {
                        id: 2,
                        path: "assets/images/ScienceBitch_red.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/ScienceBitch_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/ScienceBitch_sblue.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/ScienceBitch_wine.jpg"
                    },
                    {
                        id: 6,
                        path: "assets/images/ScienceBitch_yellow.jpg"
                    },
                    {
                        id: 7,
                        path: "assets/images/ScienceBitch_white.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Red",
                        value: "#A61E1A",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 5,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 6,
                        name: "Yellow",
                        value: "#B48124",
                    },
                    {
                        id: 7,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "Science has its pros and cons!",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 10,
                name: "Science Fiction Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/science_blue.jpg"
                    },                  	
                    {
                        id: 2,
                        path: "assets/images/science_wine.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/science_black.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/science_sblue.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                  	{
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },
                    {
                        id: 2,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 3,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 4,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "Ever watched Rick and Morty ? If not, you have missed a sexy cartoon :(",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
            {
                id: 11,
                name: "Vibe Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/vibe.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Black",
                        value: "#292A24",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "The design on the T-Shirt says it all",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
          	{
                id: 12,
                name: "AK47 Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/ak47_white.jpg"
                    },
                ],
                sizes: [
                  	"Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Medium",
                selectedColor: 1,
                price: 350,
                description: "FAN OF RIFLES ? THEN WHY NOT PICK A 1-SHOT GUN EVEN THROUGH HELMET",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
          	{
                id: 13,
                name: "Thak GYA HUN VRO Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/thakgyahuvro.jpg"
                    },
                ],
                sizes: [
                  	"Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "White",
                        value: "#F3F2F9",
                    },
                ],
                selectedSize: "Medium",
                selectedColor: 1,
                price: 350,
                description: "Life is tough! Not everyone can face the obstacles.",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
          	{
                id: 14,
                name: "Just Pain Designer T-Shirt",
                photos: [
                    {
                        id: 1,
                        path: "assets/images/Justpain_blue.jpg"
                    },                 
                    {
                        id: 2,
                        path: "assets/images/Justpain_black.jpg"
                    },
                    {
                        id: 3,
                        path: "assets/images/Justpain_sblue.jpg"
                    },
                    {
                        id: 4,
                        path: "assets/images/Justpain_wine.jpg"
                    },
                    {
                        id: 5,
                        path: "assets/images/Justpain_yellow.jpg"
                    },
                ],
                sizes: [
                    "Small",
                    "Medium",
                    "Large",
                    "XL",
                    "XXL",
                ],  
                colors: [
                    {
                        id: 1,
                        name: "Blue",
                        value: "#2D314E",
                    },                  
                    {
                        id: 2,
                        name: "Black",
                        value: "#292A24",
                    },
                    {
                        id: 3,
                        name: "SkyBlue",
                        value: "#3F60A0",
                    },
                    {
                        id: 4,
                        name: "Wine",
                        value: "#531023",
                    },
                    {
                        id: 5,
                        name: "Yellow",
                        value: "#B48124",
                    },
                ],
                selectedSize: "Small",
                selectedColor: 1,
                price: 350,
                description: "Sshhhhh ! Pain Ahead",
              	desc:  "Material: 100% Cotton, 180 GSM bio-washed																													  Style: Regular Fit, Round Neck, Half Sleeves																												  Wash Care: Wash inside out with cold water with similar colors using a gentle cycle, use a mild detergent. Tumble dry low or hang-dry. Do not iron directly or scrub on print, iron inside-out on the lowest setting. Do not bleach.",
                inStock: true,
            },
          	
        ],
        featuredProducts: [
            1, 2, 3, 5
        ],
        latestProducts: [
            4, 5, 6, 2
        ],
        loggedInUser: null,
        verCode: null,
    },

    // Do not touch the code below
    getAllProducts: function() {
        return this.data.products;  
    },

    getFeaturedProducts: function() {
        let aP = this.getAllProducts();
        let featuredProducts = [];
        let fP = this.data.featuredProducts;
        for(let i=0; i<fP.length; i++) {
            for(let j=0; j<aP.length; j++) {
                if(fP[i] == aP[j].id) {
                    featuredProducts.push(aP[j]);
                }
            }
        }
        return featuredProducts;
    },

    getLatestProducts: function() {
        let latestProducts = [];
        let aP = this.getAllProducts();
        let lP = this.data.latestProducts;  
        for(let i=0; i<lP.length; i++) {
            for(let j=0; j<aP.length; j++) {
                if(lP[i] == aP[j].id) {
                    latestProducts.push(aP[j]);
                }
            }
        }
        return latestProducts;
    },

    getProductById: function(id) {
        let aP = this.getAllProducts();
        for(let i=0; i<aP.length; i++) {
            if(aP[i].id == id) {
                return aP[i];
            }
        }
    },

    genRandNum: function(length) {
        var result = '';
        var characters = '0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
          result += characters.charAt(Math.floor(Math.random() * charactersLength));
       }
       return result;
    },

    sendCode: function(userInfo, code) {
        $.ajax({ 
             url: 'admin/email.php', 
             data: userInfo,
             type: 'POST',
             success: function (data) {
                 $("#displayName").attr("disabled", true);
                 $("#userMobile").attr("disabled", true);
                 $("#userEmail").attr("disabled", true);
                 $("#verCode").attr("disabled", false);
                 $("#verCode").focus();
                 $(".login-submit-btn").html("Sign Up");
                 let msg = "Code Successfully sent to your email! Please Check All Messages or Spam Folder in your E-mail";
                 Main.formMsg(msg, "text-green");
                 Model.data.verCode = code;
                 console.log(data);
             },
             error: function (error) {
                 console.log(error);
             },
       });
    },

    sendEnquiryMail: function(body) {
        $.ajax({ 
            url: 'admin/enquirymail.php', 
            data: body,
            type: 'POST',
            success: function (data) {
                let msg = "Your enquiry has been submitted. We will get back to you within 24 hours.";
                $(".contact-form-msg").html(msg);
                console.log(data);
            },
            error: function (error) {
                console.log(error);
            },
      });
    },

    loggingIn: function(userInfo) {
        localStorage.setItem("loggedInUser", JSON.stringify(userInfo));
        window.location.href = "/";
    }
};

export { Model };