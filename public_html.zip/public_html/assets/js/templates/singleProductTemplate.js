let singleProductTemplate = 


Handlebars.registerPartial(
    "singleProduct",
    singleProductTemplate
);
