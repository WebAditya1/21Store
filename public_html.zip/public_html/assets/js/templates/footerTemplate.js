let footerTemplate =
'<div class="container">'+
    '<div class="row">'+
        '<div class="footer-col-2">'+
            '<img src="assets/images/21storeblack.png">'+
            '<p>Our purpose is to serve everyone the best wear possible and in the minimal time.</p>'+
        '</div>'+
        '<div class="footer-col-3">'+
            '<h3>Useful Links</h3>'+
            '<ul>'+
                '<a href="about.html"><li>About Us</li></a>'+
                '<a href="return.html"><li>Return and Exchange Policy</li></a>'+
                '<a href="shipping.html"><li>Shipping Policy</li></a>'+
            '</ul>'+
        '</div>'+
        '<div class="footer-col-4">'+
            '<h3>Follow Us</h3>'+
            '<ul>'+
                '<li>Facebook</li>'+
                '<li>Instagram</li>'+
                '<li>You Tube</li>'+
                '<li>Twitter</li>'+
            '</ul>'+
        '</div>'+
    '</div>'+
    '<hr>'+
    '<p class="copyright">Copyright &copy; 2021 - 21 Store </p>'+
'</div>';


Handlebars.registerPartial(
    "footer",
    footerTemplate
);