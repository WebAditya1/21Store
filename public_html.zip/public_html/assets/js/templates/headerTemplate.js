let headerTemplate =
'<div class="logo">'+
    '<a href="index.html"><img src="assets/images/logo_bg.png" width="125px"></a>'+
'</div>'+
'<nav>'+
    '<ul id="menu-items">'+
        '<li class="close-menu-cont"><span class="close-menu">&times;</span></li>'+
        '<li><a href="products.html">Products</a></li>'+
        '<li><a href="contact.html">Contact Us</a></li>'+
        '{{#if name}}'+
        '<li class="user-cont">'+
            '<a class="display-name">'+
                '<span>Hi, {{name}}</span><ion-icon name="chevron-down" class="ionicon"></ion-icon>'+
            '</a>'+
            '<div class="dropdown-cont disappear">'+
                '<a class="dropdown-item logout-btn">Logout</a>'+
            '</div>'+
        '</li>'+
        '{{else}}'+
        '<li><a class="login-btn">Login</a></li>'+
        '{{/if}}'+
    '</ul>'+
'</nav>'+
'<p>'+
    '{{#if name}}'+
    '<a href="cart.html" class="cart-icon">'+
        '<img src="assets/images/cart.png" width="50px" height="35px">'+
        '<span>{{cart.length}}</span>'+
    '</a>'+
    '{{else}}'+
    '<a class="login-btn">'+
        '<img src="assets/images/cart.png" width="50px" height="35px">'+
    '</a>'+
    '{{/if}}'+
'</p>'+
'<img src="assets/images/menu.png" class="menu-icon">';

Handlebars.registerPartial(
    "header",
    headerTemplate
);

// Handlebars.registerHelper('ifEquals', function(arg1, arg2, options) {
//     return (arg1.toLowerCase() == arg2.toLowerCase()) ? options.fn(this) : options.inverse(this);
// });