let productTemplate =
'{{#each products}}'+
'<div class="col-4 product-box">'+
    '<a target="blank" href="product-details.html?id={{id}}">'+
        '<img src="{{photos.0.path}}">'+
    '</a>'+
    '<h4>{{name}}</h4>'+
    '<div class="rating">'+
    '{{#each ratings}}'+
        '<i class="{{this}}"></i>'+
    '{{/each}}'+
    '</div>'+
    '<p>&#8377; {{price}}</p>'+
'</div>'+
'{{/each}}';

Handlebars.registerPartial(
    "product",
    productTemplate
);

// Handlebars.registerHelper('ifEquals', function(arg1, arg2, options) {
//    return (arg1.toLowerCase() == arg2.toLowerCase()) ? options.fn(this) : options.inverse(this);
// });


