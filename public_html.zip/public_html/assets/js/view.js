export { applyTemplates };

function applyTemplates(targetid, templateid, data) {
    let target = document.getElementById(targetid);
  
    let template = Handlebars.compile(
      document.getElementById(templateid).textContent
    );
    
    target.innerHTML = template(data);
}