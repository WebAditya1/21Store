<!DOCTYPE html>
<html lang="en">

<head>
    <script>
        if(localStorage.getItem("loggedInUser") === null) {
            window.location.href = "/";
        }
    </script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>21 Store | CheckOut Page</title>

    <!-- Include Handlebars-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.7.7/handlebars.min.js"></script>
    <script src="assets/js/main.js" type="module"></script>
</head>

<body>
    <div class="container">
        <div id="header-cont" class="navbar">

        </div>
    </div>

    <div class="row pay">
        <div class="col-2">
            <form method="post" action="pay.php">
                <h3>Shipping Address</h3>
                <br>

                <input type="hidden" name="ORDER_ID" value="">
                <input type="hidden" name="CUST_ID" value="">
                <input type="hidden" name="INDUSTRY_TYPE_ID" value="Retail">
                <input type="hidden" name="CHANNEL_ID" value="WEB">
                <input type="hidden" name="TXN_AMOUNT" value="" readonly>

                <label for="fname">*Full Name</label>
                <input class="address-field" type="text" id="fname" name="fullname" placeholder="Full Name" required>

                <label for="mobile">*Mobile</label>
                <input class="address-field" type="tel" minlength="10" inputmode="numeric" id="mobile" name="mobile" placeholder="Mobile Number" required>
              
              	<label for="mobile">*EMAIL</label>
                <input class="address-field" type="email" id="mail" name="Email" placeholder="E-mail" required>

                <label for="addrl1">*Address</label>
                <input class="address-field" type="text" id="addrl1" name="addrl1" placeholder="Address Line 1" required>
                <input class="address-field" type="text" id="addrl2" name="addrl2" placeholder="Address Line 2(optional)">

                <label for="landmark">Landmark</label>
                <input class="address-field" type="text" id="landmark" name="landmark" placeholder="Landmark(optional)">

                <label for="city">*City</label>
                <input class="address-field" type="text" id="city" name="city" placeholder="Enter City" required>

                <label for="state">*State</label>
                <input class="address-field" type="text" id="state" name="state" placeholder="Enter State" required>

                <label for="country">*Country</label>
                <input class="address-field" type="text" id="country" name="country" placeholder="Enter Country" value="India" required>

                <label for="pincode">*Pincode</label>
                <input class="address-field" type="text" id="pincode" name="pincode" placeholder="Enter pincode" required>
                
                <input class="btn" type="submit" value="Continue to checkout">
            </form>
        </div>
        <div class="col-2 bill-box">
            <p>Order ID - <span class="orderid-cont"></span></p><br>
            <p>Customer ID - <span class="custid-cont"></span></p><br>
            <p>Payable Amount - &#8377; <span class="payamount-cont"></span></p>

            <div class="address">
              <br>
              <p><b>Ship to - </b></p>
                <span class="fullname-cont"></span>
                <span class="mobile-cont"></span>
                <span class="addrl1-cont"></span>
                <span class="addrl2-cont"></span>
                <span class="landmark-cont"></span>
                <span class="city-cont"></span>
                <span class="state-cont"></span>
                <span class="country-cont"></span>
                <span class="pincode-cont"></span>
            </div>
        </div>
    </div>

    <!-- footer -->
    <div id="footer-cont" class="footer">
        <!-- From Templates -->
    </div>

    <!-- Templates -->
    <!-- Header template -->
    <script src="assets/js/templates/headerTemplate.js"></script>
    <script id="header-template" type="text/x-handlebars-template">
        {{> header}}
    </script>

    <!-- Footer Template -->
    <script src="assets/js/templates/footerTemplate.js"></script>
    <script id="footer-template" type="text/x-handlebars-template">
        {{> footer}}
    </script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>

</html>