<?php

require('config.php');
require('razorpay-php/Razorpay.php');
session_start();

// Create the Razorpay Order

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);

$ORDER_ID = $_POST["ORDER_ID"];
$CUST_ID = $_POST["CUST_ID"];
$TXN_AMOUNT = $_POST["TXN_AMOUNT"];
$NAME = $_POST["fullname"];
$CONTACT = $_POST["mobile"];
$EMAIL = $_POST["Email"];
$ADDRESS = $_POST["addrl1"];

// We create an razorpay order using orders api
// Docs: https://docs.razorpay.com/docs/orders

$orderData = [
    'receipt'         => $ORDER_ID,
    'amount'          => $TXN_AMOUNT * 100, // in paise
    'currency'        => 'INR',
    'payment_capture' => 1 // auto capture
];

$razorpayOrder = $api->order->create($orderData);

$razorpayOrderId = $razorpayOrder['id'];

$_SESSION['razorpay_order_id'] = $razorpayOrderId;

$displayAmount = $amount = $orderData['amount'];

if ($displayCurrency !== 'INR')
{
    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => "21 Store",
    "description"       => "The best place for T-Shirt Designs",
    "image"             => "./assets/images/21store.png",
    "prefill"           => [
    "name"              => $NAME,
    "contact"           => $CONTACT,
    "email"				=> $EMAIL,
    ],
    "notes"             => [
    "address"           => $ADDRESS,
    "merchant_order_id" => $CUST_ID,
    ],
    "theme"             => [
    "color"             => "#373f51"
    ],
    "order_id"          => $razorpayOrderId,
];

if ($displayCurrency !== 'INR')
{
    $data['display_currency']  = $displayCurrency;
    $data['display_amount']    = $displayAmount;
}

$json = json_encode($data);
?>

<script src="https://code.jquery.com/jquery-3.5.0.js"></script>

<form action="verify.php" method="POST">
  <script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $data['key']?>"
    data-amount="<?php echo $data['amount']?>"
    data-currency="INR"
    data-name="<?php echo $data['name']?>"
    data-image="<?php echo $data['image']?>"
    data-description="<?php echo $data['description']?>"
    data-prefill.name="<?php echo $data['prefill']['name']?>"
    data-prefill.email="<?php echo $data['prefill']['email']?>"
    data-prefill.contact="<?php echo $data['prefill']['contact']?>"
    data-notes.shopping_order_id="3456"
    data-order_id="<?php echo $data['order_id']?>"
    <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
    <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
  >
  </script>
  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
  <input type="hidden" name="shopping_order_id" value="3456">
  <input type="hidden" name="ORDERID" value="<?php echo $orderData['receipt'] ?>">
  <input type="hidden" name="TXNAMOUNT" value="<?php echo $orderData['amount']/100 ?>">
</form>

<style>
  .razorpay-payment-button { display : none; }
</style>

<script type="text/javascript">
  $(document).ready(function(){
    $('.razorpay-payment-button').click();
  });
</script>