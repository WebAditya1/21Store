<?php
// data sent in header are in JSON format
header('Content-Type: application/json');
// takes the value from variables and Post the data
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$userEmail = $_POST['email'];
$orderId = $_POST['orderId'];
$txnAmount = $_POST['txnAmount'];
$orderDate = $_POST['orderDate'];
$address = json_decode($_POST['address']);
$cart = json_decode($_POST['cart']);
$adminMobile = "7737373171"; //to be changed
$adminSite = "21store.shop";

// Sending email to user    
$to = $userEmail;
$userSubject = "Order #".$orderId." Placed Successfully";
// Email Template
$cartData = "";

foreach($cart as $item) {
    $cartData .= "
    <tr>
        <td>
            <img src='https://21store.shop/".$item->product->photos[($item->selectedColor)-1]->path."' width='100px'>
        </td>
        <td>".$item->product->name."</td>
        <td>".$item->selectedSize."</td>
        <td>Rs. ".$item->product->price."</td>
        <td>".$item->quantity."</td>
        <td>Rs. ".$item->quantity * $item->product->price."</td>
    </tr>
    ";
}

$message = "
<html>
    <head>
    </head>
    <body>
        <center><h1>".$userSubject."</h1></center>
        <p>Dear ".$name.",<br>Your order of amount Rs.".$txnAmount." has been placed successfully. We will email you the shipping details once it is shipped.</p>
        <h3>Order Details</h3>
        <table>
            <thead>
                <th>Order Id</th>
                <th>Order Date</th>
                <th>Order Amount</th>
            </thead>
            <tbody>
                <tr>
                    <td>".$orderId."</td>
                    <td>".$orderDate."</td>
                    <td>Rs. ".$txnAmount."</td>
                </tr>
            </tbody>
        </table>
        <br>
        <br>
        <h3>Product Details</h3>
        <table>
            <thead>
                <th>Photo</th>
                <th>Name</th>
                <th>Size</th>
                <th>Rate</th>
                <th>Quantity</th>
                <th>Amount</th>
            </thead>
            <tbody>
                ".$cartData."
            </tbody>
        </table>
        <br>
        <br>
        <p>Thank you for shopping on <a href='https://21store.com'>21store.shop</a></p>
        <p>Reply on <a href='mailto:thestore021@gmail.com'>21Store</a><br>or you can call us at <a href='tel:".$adminMobile."'>".$adminMobile."</a> </p>
        <br>
        <br>
        <p>Reagrds, <br>Team 21store.shop</p>
    </body>
</html>";

$fromEmail = "welcome@21store.shop";
$header = "From:".$fromEmail." \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";
$retvaluser = mail ($to,$userSubject,$message,$header);
// email sent to user    



// Sending email to admin    
// Email Template
$adminName = "Admin";
$adminEmail = "thestore021@gmail.com"; //to be changed
$adminSubject = "Order #".$orderId." Received";;
$adminMessage = "
<html>
    <head>
        <style>

        </style>
    </head>
    <body>
        <center><h1>".$adminSubject."</h1></center>
        <p>Dear ".$adminName.",<br>Your have received a new order on ".$adminSite." of amount Rs.".$txnAmount.". Please send the shipping details/tracking id to the customer after the shipment of order</p><br>

        <h3>Order Details</h3>
        <table>
            <thead>
                <th>Order Id</th>
                <th>Order Date</th>
                <th>Order Amount</th>
            </thead>
            <tbody>
                <tr>
                    <td>".$orderId."</td>
                    <td>".$orderDate."</td>
                    <td>Rs. ".$txnAmount."</td>
                </tr>
            </tbody>
        </table>
        <br>
        <br>
        <h3>Customer Details</h3>
        <table>
            <thead>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
            </thead>
            <tbody>
                <tr>
                    <td>".$name."</td>
                    <td><a href='tel:".$mobile."'>".$mobile."</a></td>
                    <td><a href='mailto:".$userEmail."'>".$userEmail."</a></td>
                </tr>
            </tbody>
        </table>
        <br>
        <br>
        <h3>Product Details</h3>
        <table>
            <thead>
                <th>Photo</th>
                <th>Name</th>
                <th>Size</th>
                <th>Rate</th>
                <th>Quantity</th>
                <th>Amount</th>
            </thead>
            <tbody>
                ".$cartData."
            </tbody>
        </table>
        <br>
        <br>
        <h3>Shipping Address</h3>
        <table>
            <thead>
                <th>Name</th>
                <th>Mobile</th>
                <th>Addr Line 1</th>
                <th>Addr Line 2</th>
                <th>Landmark</th>
                <th>City</th>
                <th>State</th>
                <th>Country</th>
                <th>Pincode</th>
            </thead>
            <tbody>
                <tr>
                    <td>".$address->fullname."</td>
                    <td>".$address->mobile."</td>
                    <td>".$address->addrl1."</td>
                    <td>".$address->addrl2."</td>
                    <td>".$address->landmark."</td>
                    <td>".$address->city."</td>
                    <td>".$address->state."</td>
                    <td>".$address->country."</td>
                    <td>".$address->pincode."</td>
                </tr>
            </tbody>
        </table>
        <p>Don't forget to email the shipping details to the customer on <a href='mailto:".$userEmail."'>".$userEmail."</a></p>
    </body>
</html>";

$header = "From:".$fromEmail." \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";
$retvaladmin = mail ($adminEmail,$adminSubject,$adminMessage,$header);
// email sent to admin

if( $retvaluser == true && $retvaladmin == true) {
    echo json_encode(array(
        'success'=> true,
        'message' => 'Email sent successfully'
    ));
} else {
   echo json_encode(array(
      'error'=> true,
      'message' => 'Error sending email'
   ));
}
?>