<?php
// data sent in header are in JSON format
header('Content-Type: application/json');
// takes the value from variables and Post the data
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$userEmail = $_POST['email'];
$subject = $_POST['subject'];
$enquiryMsg = $_POST['message'];

// Sending email to user    
// Email Template
$message = "Dear ". $name .",<br>";
$message .= "We have received your enquiry about <b>".$subject."</b><br>";
$message .= "We will get back to you within 24 Hours";
$message .= "<br>Regards, <br>Team 21store.shop";

$from = "welcome@21store.shop";
$to = $userEmail;
$header = "From:".$from." \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";
$retvaluser = mail ($to,"Welcome to 21store.shop",$message,$header);
// email sent to user    


// Sending email to admin    
// Email Template
$adminName = "Admin";
$adminSite = "21store.shop";
$adminEmail = "thestore021@gmail.com"; //to be changed
$message = "Hi ". $adminName .",<br>";
$message .= "You have received an enquiry about <b>".$subject."</b> on ".$adminSite."<br>";
$message .= "Customer Details:<br>";
$message .= "Name: ".$name;
$message .= "<br>Mobile: ".$mobile;
$message .= "<br>Email: ".$userEmail;
$message .= "<br>Enquiry: ".$enquiryMsg;
$message .= "<br>Please contact him/her within 24 hours.";

$header = "From:".$from." \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";
$retvaladmin = mail ($adminEmail,$subject,$message,$header);


// message Notification
if( $retvaluser == true  && $retvaladmin == true) {
   echo json_encode(array(
      'success'=> true,
      'message' => 'Email sent successfully'
   ));
} else {
   echo json_encode(array(
      'error'=> true,
      'message' => 'Error sending email'
   ));
}
?>