<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// following files need to be included
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

//Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application�s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string.
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Transaction Status - Shopify | E-commerce Website Design</title>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
    <!-- Include Handlebars-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.7.7/handlebars.min.js"></script>
    <script src="assets/js/main.js" type="module"></script>
</head>

<body>
    <div class="container">
        <div id="header-cont" class="navbar">
                <!-- Header from templates -->
        </div>
    </div>

	<?php 

		if($isValidChecksum == "TRUE") {
			// echo "<b>Checksum matched and following are the transaction details:</b>" . "<br/>";
			if ($_POST["STATUS"] == "TXN_SUCCESS") {
				echo 
				'<div class="transaction">
					<div class="success">
						<i class="fa fa-check-circle fa-5x text-green"></i>
						<h3>Transaction Successful</h3><br>
					</div>
					<div class="content">
						<small><b>Your order has been received.</b></small><br>
						<small>Check you email for more details.</small><br>
						<small>Check all or spam folder in your mail if you are not able to find the email</small><br>
						<small><b>Order ID - </b>'.$_POST["ORDERID"].' </small><br>
						<small><b>Transaction Amount - </b>&#8377; '.$_POST["TXNAMOUNT"].'</small><br>
						<a href="products.html" class="btn">Continue Shopping</a>
					</div>
				</div>';

			} else {
				echo
				'<div class="transaction">
					<div class="oops">
						<i class="fa fa-exclamation-triangle fa-5x text-red"></i>
						<h3>Transaction Failed</h3><br>
					</div>
					<div class="content">
						<small>'.$_POST["RESPMSG"].'</small><br>
						<small><b>Order ID - </b>'.$_POST["ORDERID"].'</small><br>
						<small><b>Transaction Amount - </b>&#8377; '.$_POST["TXNAMOUNT"].'</small><br>
						<a href="cart.html" class="btn">Go To Cart &#8594</a>
					</div>
				</div>';
			}			
		} else {
			echo "<b>Checksum mismatched.</b>";
			//Process transaction as suspicious.
		}

	?>

	<script>

		if("<?php echo $_POST["STATUS"] ?>" == "TXN_SUCCESS") {
			let user = JSON.parse(localStorage.getItem("loggedInUser"));

			let body = "name="+user.name+"&mobile="+user.mobile+"&email="+user.email+"&orderId="+user.order.id+"&txnAmount="+user.order.amount+"&orderDate="+user.order.orderedOn+"&address="+JSON.stringify(user.order.address)+"&cart="+JSON.stringify(user.cart);

			$.ajax({ 
				url: 'admin/ordermail.php', 
				data: body,
				type: 'POST',
				success: function (data) {
					console.log(data);
				},
				error: function (error) {
					console.log(error);
				},
			});

			user.cart = [];
			localStorage.setItem("loggedInUser", JSON.stringify(user));
		}

	</script>

    

    <!-- footer -->
    <div id="footer-cont" class="footer">
        <!-- From Templates -->
    </div>

    <!-- Templates -->
    <!-- Header template -->
    <script src="assets/js/templates/headerTemplate.js"></script>
    <script id="header-template" type="text/x-handlebars-template">
        {{> header}}
    </script>

    <!-- Footer Template -->
    <script src="assets/js/templates/footerTemplate.js"></script>
    <script id="footer-template" type="text/x-handlebars-template">
        {{> footer}}
    </script>

</body>
</html>