<?php

require('config.php');

session_start();

require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if(empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);
    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Transaction Status - Shopify | E-commerce Website Design</title>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
    <!-- Include Handlebars-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.7.7/handlebars.min.js"></script>
    <script src="assets/js/main.js" type="module"></script>
</head>

<body>
    <div class="container">
        <div id="header-cont" class="navbar">
                <!-- Header from templates -->
        </div>
    </div>

  
<?php
	if ($success === true) {
	echo 
	'<div class="transaction">
		<div class="success">
			<i class="fa fa-check-circle fa-5x text-green"></i>
			<h3>Transaction Successful</h3><br>
		</div>
			<div class="content">
				<small><b>Your order has been received.</b></small><br>
				<small>Check you email for more details.</small><br>
				<small>Check all or spam folder in your mail if you are not able to find the email</small><br>
				<small><b>Order ID - </b>'.$_POST["ORDERID"].' </small><br>
				<small><b>Transaction Amount - </b>&#8377; '.$_POST["TXNAMOUNT"].'</small><br>
				<a href="products.html" class="btn">Continue Shopping</a>
			</div>
	</div>
    <script>
        let user = JSON.parse(localStorage.getItem("loggedInUser"));
        let body = "name="+user.name+"&mobile="+user.mobile+"&email="+user.email+"&orderId="+user.order.id+"&txnAmount="+user.order.amount+"&orderDate="+user.order.orderedOn+"&address="+JSON.stringify(user.order.address)+"&cart="+JSON.stringify(user.cart);
          $.ajax({ 
                  url: "admin/ordermail.php", 
                  data: body,
                  type: "POST",
                  success: function (data) {
                      console.log(data);
                  },
                  error: function (error) {
                      console.log(error);
                  },
              });

              user.cart = [];
              localStorage.setItem("loggedInUser", JSON.stringify(user));
    </script>';

} else {
	echo
		'<div class="transaction">
			<div class="oops">
				<i class="fa fa-exclamation-triangle fa-5x text-red"></i>
				<h3>Transaction Failed</h3><br>
			</div>
			<div class="content">
				<small><b>Order ID - </b>'.$_POST["ORDERID"].'</small><br>
				<small><b>Transaction Amount - </b>&#8377; '.$_POST["TXNAMOUNT"].'</small><br>
				<a href="cart.html" class="btn">Go To Cart &#8594</a>
			</div>
		</div>';
	}		
?>

<script>
	if("<?php echo $success ?>" === true) {
		let user = JSON.parse(localStorage.getItem("loggedInUser"));
		let body = "name="+user.name+"&mobile="+user.mobile+"&email="+user.email+"&orderId="+user.order.id+"&txnAmount="+user.order.amount+"&orderDate="+user.order.orderedOn+"&address="+JSON.stringify(user.order.address)+"&cart="+JSON.stringify(user.cart);
		$.ajax({ 
				url: 'admin/ordermail.php', 
				data: body,
				type: 'POST',
				success: function (data) {
					console.log(data);
				},
				error: function (error) {
					console.log(error);
				},
			});

			user.cart = [];
			localStorage.setItem("loggedInUser", JSON.stringify(user));
		}
</script>
  
    <!-- footer -->
    <div id="footer-cont" class="footer">
        <!-- From Templates -->
    </div>

    <!-- Templates -->
    <!-- Header template -->
    <script src="assets/js/templates/headerTemplate.js"></script>
    <script id="header-template" type="text/x-handlebars-template">
        {{> header}}
    </script>

    <!-- Footer Template -->
    <script src="assets/js/templates/footerTemplate.js"></script>
    <script id="footer-template" type="text/x-handlebars-template">
        {{> footer}}
    </script>

</body>
</html>
